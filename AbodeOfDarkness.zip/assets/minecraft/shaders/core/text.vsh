#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

#ifdef IS_GUI
// Boss bar objective: Guide pads it to HUD_WIDTH, this moves it to the top left corner.
const vec3 MARK = vec3(233.0, 240.0, 225.0) / 255.0;
const float HUD_WIDTH = 400.0;
const float HUD_MARGIN = 6.0;

bool isMarked(vec3 color) {
    return all(lessThan(abs(color - MARK), vec3(0.004))) || all(lessThan(abs(color - MARK * 0.25), vec3(0.004)));
}
#endif

void main() {
    vec3 shifted = Position;
#ifdef IS_GUI
    if (isMarked(Color.rgb)) shifted.x += HUD_WIDTH * 0.5 + HUD_MARGIN - 1.0 / ProjMat[0][0];
#endif
    gl_Position = ProjMat * ModelViewMat * vec4(shifted, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
