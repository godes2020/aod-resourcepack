#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

#ifdef IS_GUI
// Boss bar objective: CornerText pads it to HUD_WIDTH; here it goes to the top left corner enlarged.
const vec3 MARK = vec3(233.0, 240.0, 225.0) / 255.0;
const vec3 MARK_LABEL = vec3(243.0, 194.0, 80.0) / 255.0;
const float HUD_WIDTH = 400.0;
const float HUD_MARGIN = 3.0;
const float HUD_TOP = 16.0;
const float HUD_SCALE = 1.5;
const float BAR_TEXT_Y = 3.0;

bool near(vec3 a, vec3 b) {
    return all(lessThan(abs(a - b), vec3(0.004)));
}

bool isMarked(vec3 color) {
    return near(color, MARK) || near(color, MARK * 0.25) || near(color, MARK_LABEL) || near(color, MARK_LABEL * 0.25);
}
#endif

void main() {
    vec3 shifted = Position;
#ifdef IS_GUI
    if (isMarked(Color.rgb)) {
        float textStart = 1.0 / ProjMat[0][0] - HUD_WIDTH * 0.5;
        shifted.x = HUD_MARGIN + (Position.x - textStart) * HUD_SCALE;
        shifted.y = HUD_TOP + (Position.y - BAR_TEXT_Y) * HUD_SCALE;
    }
#endif
    gl_Position = ProjMat * ModelViewMat * vec4(shifted, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
